

<?php $__env->startSection('title', 'DataPosyandu'); ?>

<?php $__env->startSection('container'); ?>

    <div class="content">
        <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-2xl text-slate-600 dark:text-slate-500 font-medium leading-none mt-3">
        Data Posyandu
        </h2>
    </div>
    <div class="intro-y box p-5 mt-5">
        <div class="sm:flex items-center sm:mr-4 mt-2 xl:mt-0">
            <form id="tabulator-html-filter-form" class="xl:flex sm:mr-auto" >
            <div class="sm:flex items-center sm:mr-4 mt-2 xl:mt-0">
                    <?php if(session('search_message')): ?>
                        <div class="confirmation-box">
                            <div class="confirmation-content">
                                <p><?php echo e(session('search_message')); ?></p>
                                <button class="btn btn-primary w-24 confirm-button" onclick="closeConfirmationBox()">OK</button>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Add your CSS styles -->
                    <style>
                    .confirmation-box {
                        position: fixed;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        background-color: #fff;
                        border: 1px solid #ccc;
                        padding: 20px;
                        width: 300px;
                        text-align: center;
                        z-index: 9999;
                    }

                    .confirmation-content {
                        position: relative;
                    }

                    .confirm-button {
                        margin-top: 10px;
                    }
                    </style>

                    <!-- Add your JavaScript code -->
                    <script>
                    function closeConfirmationBox() {
                        var confirmationBox = document.querySelector('.confirmation-box');
                        confirmationBox.style.display = 'none';
                    }
                    </script>
                    
                        <form method="GET" action="<?php echo e(url('dataposyandu')); ?>">
                            <input id="tabulator-html-filter-value" type="text" class="form-control sm:w-56 2xl:w-full mt-2 sm:mt-0" name="keyword" placeholder="Cari posyandu ...">
                            <button class="btn btn-dark w-24 ml-4 mb-2 mt-2">Search</button>
                            </div>
                             <div class="form-group">
                <select name="puskesmas_id" id="puskesmasDropdown" class="mt-2 ml-8">
                        <option value="">Pilih Puskesmas</option>
                        <?php $__currentLoopData = $puskesmasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puskesmas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($puskesmas->id); ?>"><?php echo e($puskesmas->nama_puskesmas); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                    </form>
                    
                    
                    <div class="flex mt-5 sm:mt-0">
                    <?php if(session('success')): ?>
                        <div class="confirmation-box">
                            <div class="confirmation-content">
                                <p><?php echo e(session('success')); ?></p>
                                <button class="btn btn-primary w-24 confirm-button" onclick="closeConfirmationBox()">OK</button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <!-- Add your CSS styles -->
                    <style>
                    .confirmation-box {
                        position: fixed;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        background-color: #D3D3D3;
                        border: 1px solid #ccc;
                        padding: 20px;
                        width: 300px;
                        text-align: center;
                        z-index: 9999;
                    }

                    .confirmation-content {
                        position: relative;
                    }

                    .confirm-button {
                        margin-top: 30px;
                    }
                    </style>

                    <!-- Add your JavaScript code -->
                    <script>
                    function closeConfirmationBox() {
                        var confirmationBox = document.querySelector('.confirmation-box');
                        confirmationBox.style.display = 'none';
                    }
                    </script>
                    <a class="btn btn-dark w-32 ml-4 mb-2 mt-2" href="<?php echo e(route('posyandu.create')); ?>">Tambah Data</a>
                        </div>
                    
                </div>
                <div class="overflow-x-auto mt-8">
                <table class="table table-bordered">
         <thead class="table-dark text-center">
                <tr>
                    <th>No</th>
                    <th>Nama Posyandu</th>
                    <th>Alamat</th>
                    <th>Kelurahan</th>
                    <th>Kecamatan</th>
                    <th>Puskesmas</th>
                    <th>Edit</th>
                    <th>Hapus</th>
                </tr>
         </thead>
         <tbody id="posyanduTableBody">
         <?php $__currentLoopData = $dataposyandu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php
            $pageNumber = ($dataposyandu->currentPage() - 1) * $dataposyandu->perPage() + $keys + 1;
            ?>
            <tr class="table-dark text-center">
                <td><?php echo e($pageNumber); ?></td>
                <td><?php echo e($value->nama_posyandu); ?></td>
                <td><?php echo e($value->alamat); ?></td>
                <td><?php echo e($value->kelurahan); ?></td>
                <td><?php echo e($value->kecamatan); ?></td>
                <td><?php echo e($value->puskesmas->nama_puskesmas); ?></td>
                <td><a href="<?php echo e(route('posyandu.edit', $value->id)); ?>" class="btn btn-warning btn-sm">Edit</a></td>
                    <td>
                        <form action="<?php echo e(route('posyandu.destroy', $value->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus data ini?')">Hapus</button>
                        </form>
                    </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </table>
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#puskesmasDropdown').change(function() {
        var selectedPuskesmasId = $(this).val();

        $.ajax({
            url: '<?php echo e(route("posyandu.getPosyanduByPuskesmasOnly")); ?>',
            type: 'GET',
            data: { puskesmas_id: selectedPuskesmasId },
            success: function(response) {
                var posyanduTableBody = $('#posyanduTableBody');
                posyanduTableBody.empty();

                $.each(response, function(index, posyandu) {
                    var newRow = '<tr class="table-dark text-center">' +
                        '<td>' + (index + 1) + '</td>' +
                        '<td>' + posyandu.nama_posyandu + '</td>' +
                        '<td>' + posyandu.alamat + '</td>' +
                        '<td>' + posyandu.kelurahan + '</td>' +
                        '<td>' + posyandu.kecamatan + '</td>' +
                        '<td>' + posyandu.puskesmas.nama_puskesmas + '</td>' +
                        '<td>' +  '<a href="/posyandu/edit/' + posyandu.id + '" class="btn btn-warning btn-sm">Edit</a>' + '</td>' +
                        '<td>' + '<button class="btn btn-danger btn-sm btn-delete-posyandu" data-puskesmas-id="' + selectedPuskesmasId + '" data-posyandu-id="' + posyandu.id + '" >Delete</button>' +'</td>' +
                        '</tr>';
                    posyanduTableBody.append(newRow);
                });
            }
        });
    });
    
});
function deletePosyandu(puskesmasId, posyanduId) {
        if (confirm('Anda yakin ingin menghapus data ini?')) {
            $.ajax({
        url: '<?php echo e(route("posyandu.delete")); ?>',
        type: 'DELETE',
        data: {
            puskesmas_id: puskesmasId,
            posyandu_id: posyanduId,
            _token: '<?php echo e(csrf_token()); ?>',
        },
                success: function(response) {
                    // Tambahkan tindakan setelah data berhasil dihapus, seperti memuat ulang halaman atau mengupdate tampilan
                    console.log('Data berhasil dihapus');
                    window.location.href = '<?php echo e(route('dataposyandu')); ?>';
                },
                error: function(xhr, status, error) {
                    // Tambahkan tindakan jika terjadi kesalahan saat menghapus data
                    console.error('Terjadi kesalahan saat menghapus data:', error);
                }
            });
        }
    }
    // onclick button
$(document).on('click', '.btn-delete-posyandu', function() {
    var puskesmasId = $(this).data('puskesmas-id');
    var posyanduId = $(this).data('posyandu-id');
    deletePosyandu(puskesmasId, posyanduId);
    window.location.href = '<?php echo e(route('dataposyandu')); ?>';
});
</script>

     </form>
</div>
     <br>
        <?php echo e($dataposyandu->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dataposyandu.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drive\TA_internal\laravel\simozia\resources\views/dataposyandu/index.blade.php ENDPATH**/ ?>