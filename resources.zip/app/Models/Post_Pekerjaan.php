<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siswa_Kelas extends Model
{
    protected $table='post_pekerjaan';
    protected $primaryKey='id_post_pekerjaan';
    public $timestamps = false;
}