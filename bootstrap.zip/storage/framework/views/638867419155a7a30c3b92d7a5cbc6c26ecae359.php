<table class="table table-bordered">
         <thead class="table-dark text-center">
                <tr>
                    <th>Nama</th>
                    <th>Nama Ibu</th>
                    <th>Alamat</th>
                    <th>Jenis Kelamin</th>
                    <th>Umur</th>
                    <th>Berat Badan</th>
                    <th>Panjang Badan</th>
                    <th>Detak Jantung</th>
                    <th>Sistolik</th>
                    <th>Diastolik</th>
                    <th>Zscore Berat Badan</th>
                    <th>Zscore Panjang Badan</th>
                    <th>Klasifikasi Berat Badan</th>
                    <th>Klasifikasi Panjang Badan</th>
                    <th>Klasifikasi Detak Jantung</th>
                    <th>Puskesmas</th>
                    <th>Posyandu</th>
                </tr>
         </thead>
         <tbody id="balitaTableBody">
         <?php $__currentLoopData = $databalita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="table-dark text-center">
                <td><?php echo e($value->nama_anak); ?></td>
                <td><?php echo e($value->nama_ibu); ?></td>
                <td><?php echo e($value->alamat); ?></td>
                <td><?php echo e($value->jenis_kelamin); ?></td>
                <td><?php echo e($value->umur); ?></td>
                <td><?php echo e($value->berat_badan); ?></td>
                <td><?php echo e($value->panjang_badan); ?></td>
                <td><?php echo e($value->detak_jantung); ?></td>
                <td><?php echo e($value->sistolik); ?></td>
                <td><?php echo e($value->diastolik); ?></td>
                <td><?php echo e($value->zscore_berat_badan); ?></td>
                <td><?php echo e($value->zscore_panjang_badan); ?></td>
                <td><?php echo e($value->klasifikasi_berat_badan); ?></td>
                <td><?php echo e($value->klasifikasi_panjang_badan); ?></td>
                <td><?php echo e($value->klasifikasi_detak_jantung); ?></td>
                <td><?php echo e($value->puskesmas->nama_puskesmas); ?></td>
                <td><?php echo e($value->posyandu->nama_posyandu); ?></td>
            </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\drive\TA_internal\laravel\simozia\resources\views/databalita/balita.blade.php ENDPATH**/ ?>