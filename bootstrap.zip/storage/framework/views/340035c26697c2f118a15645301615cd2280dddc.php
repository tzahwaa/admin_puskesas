

<?php $__env->startSection('title', 'DataPosyandu'); ?>

<?php $__env->startSection('container'); ?>
<div class="content">
        <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-2xl text-slate-600 dark:text-slate-500 font-medium leading-none mt-3">
        Edit Data Posyandu
        </h2>
    </div>
    <div class="intro-y box p-5 mt-5">
        <div class="intro-y  items-center mt-8">
        <form method="POST" action="<?php echo e(route('posyandu.update', $value->id)); ?>">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Nama Posyandu</label>
                <input type="text" name="nama_posyandu" value="<?php echo e($value->nama_posyandu); ?>" class="form-control">
                <?php $__errorArgs = ['nama_posyandu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group mt-5">
                <label>Alamat</label>
                <input type="text" name="alamat" value="<?php echo e($value->alamat); ?>" class="form-control">
                 <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group mt-5">
                <label>Kelurahan</label>
                <input type="text" name="kelurahan" value="<?php echo e($value->kelurahan); ?>" class="form-control">
                 <?php $__errorArgs = ['kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group mt-5">
                <label>Kecamatan</label>
                <input type="text" name="kecamatan" value="<?php echo e($value->kecamatan); ?>" class="form-control">
                <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="text-center mt-12">
				<button class="btn btn-primary w-24 mr-3" style="margin-right: 6px;" type="submit">Simpan</button>
				<a href="<?php echo e(route('dataposyandu')); ?>" class="btn btn-danger w-24 ml-3">Batal</a>
			</div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dataposyandu.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drive\TA_internal\laravel\simozia\resources\views/dataposyandu/edit.blade.php ENDPATH**/ ?>