

<!-- <?php $__env->startSection('title', 'Databalita   '); ?> -->

<?php $__env->startSection('container'); ?>

    <div class="content">
        <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-2xl text-slate-600 dark:text-slate-500 font-medium leading-none mt-3">
        Data Balita
        </h2>
    </div>
    <div class="intro-y box p-5 mt-5">
                <div class="flex flex-col sm:flex-row sm:items-end xl:items-start">
                    <form id="tabulator-html-filter-form" class="xl:flex sm:mr-auto" >
                        <div class="sm:flex items-center sm:mr-4">
                            <label class="w-12 flex-none xl:w-auto xl:flex-initial mr-2">Puskesmas</label>
                            <select name="puskesmas_id" id="puskesmasDropdown">
                                <option value="">Pilih Puskesmas</option>
                                <?php $__currentLoopData = $puskesmasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puskesmas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($puskesmas->id); ?>">
                                    <?php echo e($puskesmas->nama_puskesmas); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="sm:flex items-center sm:mr-4">
                            <label class="w-12 flex-none xl:w-auto xl:flex-initial mr-2">Posyandu</label>
                            <select name="posyandu_id" id="posyanduDropdown">
                                <option value="">Pilih Posyandu</option>
                            </select>
                        </div>
                        <div class="sm:flex items-center sm:mr-4 mt-2 xl:mt-0">
                            <?php if(session('search_message')): ?>
                                <div class="confirmation-box">
                                    <div class="confirmation-content">
                                        <p><?php echo e(session('search_message')); ?></p>
                                        <button class="btn btn-primary w-24 confirm-button" onclick="closeConfirmationBox()">OK</button>
                                    </div>
                                </div>
                            <?php endif; ?>

                    <!-- Add your CSS styles -->
                    <style>
                    .confirmation-box {
                        position: fixed;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        background-color: #fff;
                        border: 1px solid #ccc;
                        padding: 20px;
                        width: 300px;
                        text-align: center;
                        z-index: 9999;
                    }

                    .confirmation-content {
                        position: relative;
                    }

                    .confirm-button {
                        margin-top: 10px;
                    }
                    </style>

                    <!-- Add your JavaScript code -->
                    <script>
                    function closeConfirmationBox() {
                        var confirmationBox = document.querySelector('.confirmation-box');
                        confirmationBox.style.display = 'none';
                    }
                    </script>
                        <form method="GET" action="<?php echo e(url('datapuskesmas')); ?>">
                            <input id="tabulator-html-filter-value" type="text" class="form-control sm:w-56 2xl:w-full mt-2 sm:mt-0" name="keyword" placeholder="Cari nama balita ...">
                            <button class="btn btn-dark w-24 ml-4 mb-2 mt-2">Search</button>
                            </div>
                    </form>
                    <div class="flex mt-5 sm:mt-0">
                        <div class="dropdown w-1/2 sm:w-auto">
                        <a href="<?php echo e(route('balita.export')); ?>"  class="btn btn-warning w-50 mr-5 mb-2 mt-2" >Export Excel</a>
                        </div>
                    </div>
                </div>
                <div class="overflow-x-auto mt-8">
                <table class="table table-bordered">
         <thead class="table-dark text-center">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Nama Ibu</th>
                    <th>Alamat</th>
                    <th>Jenis Kelamin</th>
                    <th>Umur</th>
                    <th>Berat Badan</th>
                    <th>Panjang Badan</th>
                    <th>Detak Jantung</th>
                    <th>Sistolik</th>
                    <th>Diastolik</th>
                    <th>Zscore Berat Badan</th>
                    <th>Zscore Panjang Badan</th>
                    <th>Klasifikasi Berat Badan</th>
                    <th>Klasifikasi Panjang Badan</th>
                    <th>Klasifikasi Detak Jantung</th>
                    <th>Puskesmas</th>
                    <th>Posyandu</th>
                </tr>
         </thead>
         <tbody id="balitaTableBody">
         <?php $__currentLoopData = $databalita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php
            $pageNumber = ($databalita->currentPage() - 1) * $databalita->perPage() + $keys + 1;
            ?>
            <tr class="table-dark text-center">
                <td><?php echo e($pageNumber); ?></td>
                <td><?php echo e($value->nama_anak); ?></td>
                <td><?php echo e($value->nama_ibu); ?></td>
                <td><?php echo e($value->alamat); ?></td>
                <td><?php echo e($value->jenis_kelamin); ?></td>
                <td><?php echo e($value->umur); ?></td>
                <td><?php echo e($value->berat_badan); ?></td>
                <td><?php echo e($value->panjang_badan); ?></td>
                <td><?php echo e($value->detak_jantung); ?></td>
                <td><?php echo e($value->sistolik); ?></td>
                <td><?php echo e($value->diastolik); ?></td>
                <td><?php echo e($value->zscore_berat_badan); ?></td>
                <td><?php echo e($value->zscore_panjang_badan); ?></td>
                <td><?php echo e($value->klasifikasi_berat_badan); ?></td>
                <td><?php echo e($value->klasifikasi_panjang_badan); ?></td>
                <td><?php echo e($value->klasifikasi_detak_jantung); ?></td>
                <td><?php echo e($value->puskesmas->nama_puskesmas); ?></td>
                <td><?php echo e($value->posyandu->nama_posyandu); ?></td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
     </table>
</div>
     <br>
        <?php echo e($databalita->links()); ?>

        <br/>
<br/>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- <script src="<?php echo e(url('filter.js')); ?>"></script> -->

<script>
$(document).ready(function() {
    // Fungsi untuk memperbarui dropdown Posyandu berdasarkan Puskesmas yang dipilih
    $('#puskesmasDropdown').change(function() {
        var selectedPuskesmasId = $(this).val();

        // Hapus data Posyandu yang ada
        $('#posyanduDropdown').empty().append('<option value="">Pilih Posyandu</option>');

        // Jika Puskesmas terpilih, ambil data Posyandu dari server
        if (selectedPuskesmasId) {
            $.ajax({
                url: '<?php echo e(route("posyandu.getPosyanduByPuskesmas")); ?>',
                type: 'GET',
                data: { puskesmas_id: selectedPuskesmasId },
                success: function(response) {
                    // Tambahkan data Posyandu ke dropdown
                    $.each(response, function(index, posyandu) {
                        $('#posyanduDropdown').append('<option value="' + posyandu.id + '">' + posyandu.nama_posyandu + '</option>');
                    });
                }
            });
        }
    });

    // Fungsi untuk memperbarui tabel Balita berdasarkan Puskesmas dan Posyandu yang dipilih
    $('#posyanduDropdown').change(function() {
        var selectedPuskesmasId = $('#puskesmasDropdown').val();
        var selectedPosyanduId = $(this).val();

        // Hapus data Balita yang ada
        $('#balitaTableBody').empty();

        // Jika Puskesmas dan Posyandu terpilih, ambil data Balita dari server
        if (selectedPuskesmasId && selectedPosyanduId) {
            $.ajax({
                url: '<?php echo e(route("balita.getBalitaByPosyandu")); ?>',
                type: 'GET',
                data: { puskesmas_id: selectedPuskesmasId, posyandu_id: selectedPosyanduId },
                success: function(response) {
                    // Tambahkan data Balita ke tabel
                    $.each(response, function(index, balita) {
                        var newRow = '<tr class="table-dark text-center">' +
                            '<td>' + (index + 1) + '</td>' +
                            '<td>' + balita.nama_anak + '</td>' +
                            '<td>' + balita.nama_ibu + '</td>' +
                            '<td>' + balita.alamat + '</td>' +
                            '<td>' + balita.jenis_kelamin + '</td>' +
                            '<td>' + balita.umur + '</td>' +
                            '<td>' + balita.berat_badan + '</td>' +
                            '<td>' + balita.panjang_badan + '</td>' +
                            '<td>' + balita.detak_jantung + '</td>' +
                            '<td>' + balita.sistolik + '</td>' +
                            '<td>' + balita.diastolik + '</td>' +
                            '<td>' + balita.zscore_berat_badan + '</td>' +
                            '<td>' + balita.zscore_panjang_badan + '</td>' +
                            '<td>' + balita.klasifikasi_berat_badan + '</td>' +
                            '<td>' + balita.klasifikasi_panjang_badan + '</td>' +
                            '<td>' + balita.klasifikasi_detak_jantung + '</td>' +
                            '<td>' + balita.puskesmas.nama_puskesmas + '</td>' +
                            '<td>' + balita.posyandu.nama_posyandu + '</td>' +
                            '</tr>';
                        $('#balitaTableBody').append(newRow);
                    });
                }
            });
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('databalita.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\drive\TA_internal\laravel\simozia\resources\views/databalita/index.blade.php ENDPATH**/ ?>